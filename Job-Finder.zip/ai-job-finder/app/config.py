"""
Central configuration for the AI Job Finder system.

Everything here is loaded from environment variables (see .env.example).
No secrets or values are hard-coded. This is the ONLY module that should
call os.getenv directly — every other module imports `settings` from here.
"""
from __future__ import annotations

import os
from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Global kill switch (Phase 20) ---------------------------------
    # When false, no automated outreach or reply can be sent, full stop.
    # Checked in app/policy/policy_gate.py on every single outbound action.
    AUTOMATION_ENABLED: bool = False

    # --- App / environment ------------------------------------------------
    ENV: Literal["development", "production"] = "development"
    SECRET_KEY: str = Field(..., description="Used to sign dashboard session cookies")

    # --- Database -----------------------------------------------------
    DATABASE_URL: str = Field(
        default="postgresql+psycopg://postgres:postgres@localhost:5432/ai_job_finder",
        description="SQLAlchemy-style Postgres connection string",
    )

    # --- AI provider (Phase 18) ----------------------------------------
    AI_PROVIDER: Literal["anthropic", "openai", "gemini", "ollama"] = "anthropic"
    ANTHROPIC_API_KEY: str | None = None
    OPENAI_API_KEY: str | None = None
    GEMINI_API_KEY: str | None = None
    OLLAMA_BASE_URL: str = "http://localhost:11434"

    # --- Business rules (Phase 12) --------------------------------------
    MIN_PROJECT_BUDGET_USD: int = 300
    MAX_DISCOUNT_PERCENT: int = 10
    LEAD_SCORE_HANDOFF_THRESHOLD: int = 81
    MAX_OUTREACH_MESSAGES_PER_DAY: int = 25

    # --- Handoff (Phase 10) ---------------------------------------------
    WHATSAPP_NUMBER: str = Field(..., description="E.164 format, no plus sign, e.g. 923001234567")
    NOTIFICATION_CHANNEL: Literal["email", "telegram", "webhook"] = "email"
    NOTIFICATION_EMAIL: str | None = None
    NOTIFICATION_TELEGRAM_BOT_TOKEN: str | None = None
    NOTIFICATION_TELEGRAM_CHAT_ID: str | None = None
    NOTIFICATION_WEBHOOK_URL: str | None = None

    # --- Quiet hours (Phase 20) ------------------------------------------
    QUIET_HOURS_START: int = 22  # 24h local hour, no outreach starts after this
    QUIET_HOURS_END: int = 7

    # --- Dashboard auth ---------------------------------------------------
    ADMIN_EMAIL: str = Field(...)
    ADMIN_PASSWORD_HASH: str = Field(..., description="bcrypt hash, generate with scripts/hash_password.py")


@lru_cache
def get_settings() -> Settings:
    """Cached so we don't re-parse env vars on every request."""
    return Settings()


settings = get_settings()
