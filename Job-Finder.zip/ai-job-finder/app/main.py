from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api.routes import automation, health, leads, opportunities
from app.config import settings


@asynccontextmanager
async def lifespan(_app: FastAPI):
    # Deliberately quiet startup — no external calls here. Connector
    # polling is scheduled separately (app/scheduler/jobs.py), not
    # triggered on app boot, so a redeploy never causes a burst of
    # duplicate outreach.
    print(f"AI Job Finder starting | env={settings.ENV} | automation_enabled(default)={settings.AUTOMATION_ENABLED}")
    yield


app = FastAPI(
    title="AI Job Finder + Sales Agent",
    description="Autonomous opportunity discovery and lead-qualification system.",
    version="0.1.0",
    lifespan=lifespan,
)

app.include_router(health.router)
app.include_router(opportunities.router)
app.include_router(leads.router)
app.include_router(automation.router)

# Routers not yet wired in this pass — added in later phases:
# app.include_router(conversations.router)
# app.include_router(portfolio.router)
# app.include_router(settings_routes.router)
# app.include_router(analytics.router)
