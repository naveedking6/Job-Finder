from app.models.activity import ActivityLog, Notification  # noqa: F401
from app.models.business import AutomationRule, PortfolioItem, Service  # noqa: F401
from app.models.conversation import Conversation, ConversationMemory, Message  # noqa: F401
from app.models.lead import Client, Lead, LeadScoreHistory  # noqa: F401
from app.models.opportunity import Opportunity  # noqa: F401
from app.models.platform import AIProviderConfig, Platform  # noqa: F401
