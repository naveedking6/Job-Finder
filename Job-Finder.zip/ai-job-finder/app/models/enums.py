import enum


class PlatformCapability(str, enum.Enum):
    """
    The single most important enum in the system.

    discover_only     -> connector may read/find opportunities, may NEVER
                          send automated messages of any kind.
    discover_respond  -> connector may both discover AND send automated
                          outreach/replies, because the platform's own
                          rules/API explicitly permit it.

    This is enforced in app/policy/policy_gate.py, not just documented here.
    """

    DISCOVER_ONLY = "discover_only"
    DISCOVER_RESPOND = "discover_respond"


class OpportunityStatus(str, enum.Enum):
    NEW = "new"
    SCORED = "scored"
    IGNORED = "ignored"
    PROMOTED_TO_LEAD = "promoted_to_lead"


class LeadStage(str, enum.Enum):
    """Phase 14 pipeline, in order."""

    OPPORTUNITY_FOUND = "opportunity_found"
    OPPORTUNITY_ANALYZED = "opportunity_analyzed"
    QUALIFIED_FOR_OUTREACH = "qualified_for_outreach"
    INITIAL_CONTACT_SENT = "initial_contact_sent"
    CLIENT_RESPONDED = "client_responded"
    REQUIREMENTS_GATHERING = "requirements_gathering"
    SOLUTION_DISCUSSION = "solution_discussion"
    PORTFOLIO_SHARED = "portfolio_shared"
    BUDGET_DISCUSSION = "budget_discussion"
    TIMELINE_DISCUSSION = "timeline_discussion"
    LEAD_QUALIFIED = "lead_qualified"
    READY_FOR_HANDOFF = "ready_for_handoff"
    CONVERTED = "converted"
    LOST = "lost"
    ARCHIVED = "archived"


class ConversationStatus(str, enum.Enum):
    ACTIVE = "active"
    HANDED_OFF = "handed_off"
    CLOSED = "closed"


class MessageSender(str, enum.Enum):
    CLIENT = "client"
    AI = "ai"
    HUMAN = "human"


class NotificationChannel(str, enum.Enum):
    WHATSAPP = "whatsapp"
    EMAIL = "email"
    TELEGRAM = "telegram"


class NotificationReason(str, enum.Enum):
    LEAD_SCORE_THRESHOLD = "lead_score_threshold"
    CLIENT_REQUESTED_CONTACT = "client_requested_contact"
    AI_UNCERTAIN = "ai_uncertain"
