from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Numeric, String, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from app.models.types import PortableJSON
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base
from app.models.enums import OpportunityStatus


class Opportunity(Base):
    """
    A single job/lead posting after normalization (see app/normalizer/).

    `external_ref` + `platform_id` uniqueness is the duplicate-detection
    mechanism required in Phase 22 — the same job seen twice from the same
    source (e.g. re-polled RSS feed) never creates a second row.
    """

    __tablename__ = "opportunities"
    __table_args__ = (UniqueConstraint("platform_id", "external_ref", name="uq_platform_external_ref"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    platform_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("platforms.id"), nullable=False)

    external_ref: Mapped[str] = mapped_column(String(500), nullable=False)
    raw_payload: Mapped[dict] = mapped_column(PortableJSON, default=dict)

    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str] = mapped_column(String, nullable=False)
    country: Mapped[str | None] = mapped_column(String(100), nullable=True)
    language: Mapped[str | None] = mapped_column(String(20), nullable=True)
    budget_min: Mapped[float | None] = mapped_column(Numeric(10, 2), nullable=True)
    budget_max: Mapped[float | None] = mapped_column(Numeric(10, 2), nullable=True)

    relevance_score: Mapped[int | None] = mapped_column(nullable=True)  # 0-100
    relevance_reasoning: Mapped[str | None] = mapped_column(String, nullable=True)

    status: Mapped[str] = mapped_column(String(30), default=OpportunityStatus.NEW.value, nullable=False)

    discovered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
