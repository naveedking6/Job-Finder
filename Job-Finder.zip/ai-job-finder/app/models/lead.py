from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Numeric, String, func
from sqlalchemy.dialects.postgresql import UUID
from app.models.types import PortableJSON
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base
from app.models.enums import LeadStage


class Client(Base):
    """
    A real-world person/business. `contact_info` is only ever populated
    once legitimately provided by the client themselves (Phase 10) —
    never scraped or inferred.
    """

    __tablename__ = "clients"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    country: Mapped[str | None] = mapped_column(String(100), nullable=True)
    language: Mapped[str | None] = mapped_column(String(20), nullable=True)
    contact_info: Mapped[dict] = mapped_column(PortableJSON, default=dict)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Lead(Base):
    """
    The central pipeline object. `opportunity_id` is nullable because a
    lead can originate from direct inbound contact (e.g. your own site's
    contact form) with no prior discovered Opportunity.
    """

    __tablename__ = "leads"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    opportunity_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("opportunities.id"), nullable=True)
    client_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("clients.id"), nullable=False)

    stage: Mapped[str] = mapped_column(String(40), default=LeadStage.OPPORTUNITY_FOUND.value, nullable=False)
    lead_score: Mapped[int] = mapped_column(default=0, nullable=False)
    lead_score_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    estimated_budget: Mapped[float | None] = mapped_column(Numeric(10, 2), nullable=True)
    project_summary: Mapped[str | None] = mapped_column(String, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class LeadScoreHistory(Base):
    """
    Append-only score history so the dashboard can show trajectory
    ('40 -> 85 after client said let's start'), not just current value.
    """

    __tablename__ = "lead_scores"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    lead_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=False)
    score: Mapped[int] = mapped_column(nullable=False)
    signals: Mapped[dict] = mapped_column(PortableJSON, default=dict)  # which positive/negative signals fired
    scored_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
