from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID
from app.models.types import PortableJSON
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base
from app.models.enums import PlatformCapability


class Platform(Base):
    """
    One row per source connector, e.g. 'own_site', 'rss_jobboards', 'reddit'.

    `capability` is what the policy gate checks before allowing ANY
    automated outbound action for opportunities from this platform.
    """

    __tablename__ = "platforms"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    capability: Mapped[str] = mapped_column(String(30), nullable=False, default=PlatformCapability.DISCOVER_ONLY.value)
    enabled: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    rate_limit_per_day: Mapped[int] = mapped_column(Integer, default=25, nullable=False)
    compliance_note: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class AIProviderConfig(Base):
    """
    Config for an AI provider (Phase 18). API keys are NEVER stored here —
    they live in environment variables only. This table just tracks which
    provider/model is active and non-secret config like model name.
    """

    __tablename__ = "ai_providers"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(50), nullable=False)  # anthropic | openai | gemini | ollama
    active: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    config: Mapped[dict] = mapped_column(PortableJSON, default=dict)  # e.g. {"model": "claude-sonnet-4-6"}
