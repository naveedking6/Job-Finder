from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, String, func
from sqlalchemy.dialects.postgresql import UUID
from app.models.types import PortableJSON
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base


class PortfolioItem(Base):
    __tablename__ = "portfolio_items"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    category: Mapped[str] = mapped_column(String(50), nullable=False)  # wordpress|shopify|woocommerce|redesign|...
    url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    description: Mapped[str | None] = mapped_column(String, nullable=True)
    # Stored as JSON (portable across Postgres/SQLite) rather than
    # Postgres-only ARRAY — a simple list of tag strings, e.g. ["shopify","fashion"]
    tags: Mapped[list[str]] = mapped_column(PortableJSON, default=list)


class Service(Base):
    __tablename__ = "services"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str | None] = mapped_column(String, nullable=True)
    base_price_range: Mapped[str | None] = mapped_column(String(100), nullable=True)


class AutomationRule(Base):
    """
    Key/value business rules editable from the dashboard without a code
    change (Phase 12/20) — e.g. min_budget, max_discount, quiet_hours.
    """

    __tablename__ = "automation_rules"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    key: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    value: Mapped[dict] = mapped_column(PortableJSON, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
