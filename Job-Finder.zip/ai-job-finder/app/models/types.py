"""
Dialect-aware JSON column type.

Production runs on Postgres, where we want real JSONB (indexable, faster).
But tests and local quick-checks may run against SQLite, which has no
JSONB type. `.with_variant()` lets one column definition work on both
without special-casing every model.
"""
from sqlalchemy import JSON
from sqlalchemy.dialects.postgresql import JSONB

PortableJSON = JSON().with_variant(JSONB(), "postgresql")
