from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import UUID
from app.models.types import PortableJSON
from sqlalchemy.orm import Mapped, mapped_column

from app.db.session import Base


class ActivityLog(Base):
    """
    Append-only audit trail (Phase 21). Every important decision the
    system makes gets a row here — this is what lets you answer "why did
    the AI do that" from the dashboard instead of guessing.

    NEVER write secrets into `details` — see docs/ARCHITECTURE.md.
    """

    __tablename__ = "activity_logs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    entity_type: Mapped[str] = mapped_column(String(50), nullable=False)  # 'opportunity' | 'lead' | 'conversation' | ...
    entity_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    details: Mapped[dict] = mapped_column(PortableJSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Notification(Base):
    """One row per notification actually sent to the freelancer (Phase 11)."""

    __tablename__ = "notifications"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    lead_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=False)
    channel: Mapped[str] = mapped_column(String(20), nullable=False)  # whatsapp | email | telegram
    reason: Mapped[str] = mapped_column(String(50), nullable=False)  # lead_score_threshold | client_requested_contact | ai_uncertain
    sent_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
