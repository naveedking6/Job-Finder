from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_admin
from app.models.business import AutomationRule

router = APIRouter(prefix="/automation", tags=["automation"])

AUTOMATION_ENABLED_KEY = "AUTOMATION_ENABLED"


def _set_flag(db: Session, value: bool) -> bool:
    row = db.execute(select(AutomationRule).where(AutomationRule.key == AUTOMATION_ENABLED_KEY)).scalar_one_or_none()
    if row is None:
        row = AutomationRule(key=AUTOMATION_ENABLED_KEY, value={"enabled": value})
        db.add(row)
    else:
        row.value = {"enabled": value}
    db.commit()
    return value


@router.post("/start")
def start_automation(db: Session = Depends(get_db), _admin: str = Depends(require_admin)):
    """
    Turns automated outreach/replies back on. Note: this flips the DB flag
    that app/policy/policy_gate.py reads on every action. The env var
    AUTOMATION_ENABLED in .env is the deploy-time default; this endpoint
    is the runtime override for the emergency stop button in the dashboard.
    """
    enabled = _set_flag(db, True)
    return {"automation_enabled": enabled}


@router.post("/stop")
def stop_automation(db: Session = Depends(get_db), _admin: str = Depends(require_admin)):
    """The emergency global switch from Phase 20. Stops all new automated messages immediately."""
    enabled = _set_flag(db, False)
    return {"automation_enabled": enabled}


@router.get("/status")
def automation_status(db: Session = Depends(get_db), _admin: str = Depends(require_admin)):
    row = db.execute(select(AutomationRule).where(AutomationRule.key == AUTOMATION_ENABLED_KEY)).scalar_one_or_none()
    return {"automation_enabled": bool(row.value.get("enabled")) if row else False}
