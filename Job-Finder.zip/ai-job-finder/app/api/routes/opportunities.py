from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_admin
from app.api.schemas import OpportunityOut
from app.models.opportunity import Opportunity

router = APIRouter(prefix="/opportunities", tags=["opportunities"])


@router.get("", response_model=list[OpportunityOut])
def list_opportunities(
    status: str | None = Query(default=None, description="Filter by status: new|scored|ignored|promoted_to_lead"),
    min_relevance: int | None = Query(default=None, ge=0, le=100),
    limit: int = Query(default=50, le=200),
    db: Session = Depends(get_db),
    _admin: str = Depends(require_admin),
):
    stmt = select(Opportunity).order_by(Opportunity.discovered_at.desc()).limit(limit)
    if status:
        stmt = stmt.where(Opportunity.status == status)
    if min_relevance is not None:
        stmt = stmt.where(Opportunity.relevance_score >= min_relevance)
    return db.execute(stmt).scalars().all()


@router.get("/{opportunity_id}", response_model=OpportunityOut)
def get_opportunity(
    opportunity_id: uuid.UUID,
    db: Session = Depends(get_db),
    _admin: str = Depends(require_admin),
):
    opp = db.get(Opportunity, opportunity_id)
    if opp is None:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    return opp
