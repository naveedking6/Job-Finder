from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_db, require_admin
from app.api.schemas import LeadOut, LeadStageUpdate, MessageOut
from app.models.conversation import Conversation, Message
from app.models.enums import LeadStage
from app.models.lead import Lead

router = APIRouter(prefix="/leads", tags=["leads"])


@router.get("", response_model=list[LeadOut])
def list_leads(
    stage: str | None = Query(default=None),
    min_score: int | None = Query(default=None, ge=0, le=100),
    limit: int = Query(default=50, le=200),
    db: Session = Depends(get_db),
    _admin: str = Depends(require_admin),
):
    stmt = select(Lead).order_by(Lead.updated_at.desc()).limit(limit)
    if stage:
        stmt = stmt.where(Lead.stage == stage)
    if min_score is not None:
        stmt = stmt.where(Lead.lead_score >= min_score)
    return db.execute(stmt).scalars().all()


@router.get("/{lead_id}", response_model=LeadOut)
def get_lead(lead_id: uuid.UUID, db: Session = Depends(get_db), _admin: str = Depends(require_admin)):
    lead = db.get(Lead, lead_id)
    if lead is None:
        raise HTTPException(status_code=404, detail="Lead not found")
    return lead


@router.patch("/{lead_id}/stage", response_model=LeadOut)
def update_lead_stage(
    lead_id: uuid.UUID,
    payload: LeadStageUpdate,
    db: Session = Depends(get_db),
    _admin: str = Depends(require_admin),
):
    """Manual override — lets you move a lead's stage from the dashboard."""
    lead = db.get(Lead, lead_id)
    if lead is None:
        raise HTTPException(status_code=404, detail="Lead not found")

    valid_stages = {s.value for s in LeadStage}
    if payload.stage not in valid_stages:
        raise HTTPException(status_code=400, detail=f"Invalid stage. Must be one of: {sorted(valid_stages)}")

    lead.stage = payload.stage
    db.commit()
    db.refresh(lead)
    return lead


@router.get("/{lead_id}/messages", response_model=list[MessageOut])
def get_lead_messages(lead_id: uuid.UUID, db: Session = Depends(get_db), _admin: str = Depends(require_admin)):
    """Full conversation history for a lead, across all its conversations, oldest first."""
    lead = db.get(Lead, lead_id)
    if lead is None:
        raise HTTPException(status_code=404, detail="Lead not found")

    stmt = (
        select(Message)
        .join(Conversation, Message.conversation_id == Conversation.id)
        .where(Conversation.lead_id == lead_id)
        .order_by(Message.created_at.asc())
    )
    return db.execute(stmt).scalars().all()
