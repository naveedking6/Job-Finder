from __future__ import annotations

from fastapi import APIRouter

from app.api.schemas import HealthOut
from app.config import settings

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthOut)
def health() -> HealthOut:
    """Public, unauthenticated — used by hosting platforms for uptime checks."""
    return HealthOut(status="ok", automation_enabled=settings.AUTOMATION_ENABLED)
