from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class OpportunityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    platform_id: uuid.UUID
    title: str
    description: str
    country: str | None
    language: str | None
    budget_min: float | None
    budget_max: float | None
    relevance_score: int | None
    relevance_reasoning: str | None
    status: str
    discovered_at: datetime


class LeadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    client_id: uuid.UUID
    opportunity_id: uuid.UUID | None
    stage: str
    lead_score: int
    estimated_budget: float | None
    project_summary: str | None
    created_at: datetime
    updated_at: datetime


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    sender: str
    content: str
    created_at: datetime


class LeadStageUpdate(BaseModel):
    stage: str


class HealthOut(BaseModel):
    status: str
    automation_enabled: bool
