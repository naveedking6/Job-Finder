from __future__ import annotations

from collections.abc import Generator

import bcrypt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from sqlalchemy.orm import Session

from app.config import settings
from app.db.session import SessionLocal

security = HTTPBasic()


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def require_admin(credentials: HTTPBasicCredentials = Depends(security)) -> str:
    """
    Minimal single-admin auth (Phase 25). Deliberately simple: this
    dashboard has exactly one legitimate user (you). If you later need
    multi-user auth, swap this dependency without touching route code.
    """
    valid_email = credentials.username == settings.ADMIN_EMAIL
    valid_password = bcrypt.checkpw(
        credentials.password.encode("utf-8"),
        settings.ADMIN_PASSWORD_HASH.encode("utf-8"),
    )
    if not (valid_email and valid_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username
