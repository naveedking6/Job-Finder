from __future__ import annotations

from functools import lru_cache

from app.ai.provider_interface import AIProvider
from app.config import settings


@lru_cache
def get_ai_provider() -> AIProvider:
    """
    The single place AI_PROVIDER is read. Every other module calls
    get_ai_provider() and only ever talks to the AIProvider interface —
    never a specific SDK. Changing providers is a one-line .env edit.
    """
    provider = settings.AI_PROVIDER

    if provider == "anthropic":
        from app.ai.providers.anthropic_provider import AnthropicProvider

        return AnthropicProvider()
    if provider == "openai":
        from app.ai.providers.openai_provider import OpenAIProvider

        return OpenAIProvider()
    if provider == "gemini":
        from app.ai.providers.gemini_provider import GeminiProvider

        return GeminiProvider()
    if provider == "ollama":
        from app.ai.providers.ollama_provider import OllamaProvider

        return OllamaProvider()

    raise ValueError(f"Unknown AI_PROVIDER: {provider!r}. Must be one of: anthropic, openai, gemini, ollama.")
