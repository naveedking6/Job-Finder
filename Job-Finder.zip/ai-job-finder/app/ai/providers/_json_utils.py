from __future__ import annotations

import json
import re
from typing import Any


def extract_json(text: str) -> dict[str, Any]:
    """
    Models sometimes wrap JSON in prose or ```json fences despite instructions.
    This pulls out the first {...} block and parses it, raising a clear error
    if nothing parseable is found rather than silently returning {}.
    """
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    candidate = fenced.group(1) if fenced else text

    brace_match = re.search(r"\{.*\}", candidate, re.DOTALL)
    if not brace_match:
        raise ValueError(f"No JSON object found in AI response: {text[:200]!r}")

    return json.loads(brace_match.group(0))
