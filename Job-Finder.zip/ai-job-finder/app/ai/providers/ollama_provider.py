from __future__ import annotations

from typing import Any

import httpx

from app.ai.provider_interface import AIProvider
from app.ai.providers._json_utils import extract_json
from app.config import settings


class OllamaProvider(AIProvider):
    """
    Runs against a local Ollama server (free, self-hosted). Quality is
    noticeably lower than a hosted frontier model for nuanced sales
    conversation — recommended for testing/dev or very tight budgets,
    not for production client-facing conversations. See Phase 17 notes.
    """

    def __init__(self, model: str = "llama3.1") -> None:
        self._base_url = settings.OLLAMA_BASE_URL.rstrip("/")
        self._model = model

    async def _complete(self, system: str, user: str) -> str:
        async with httpx.AsyncClient(timeout=120) as http:
            resp = await http.post(
                f"{self._base_url}/api/chat",
                json={
                    "model": self._model,
                    "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                    "stream": False,
                },
            )
            resp.raise_for_status()
            return resp.json()["message"]["content"]

    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: list[dict[str, str]],
        user_message: str,
    ) -> str:
        async with httpx.AsyncClient(timeout=120) as http:
            resp = await http.post(
                f"{self._base_url}/api/chat",
                json={
                    "model": self._model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        *conversation_history,
                        {"role": "user", "content": user_message},
                    ],
                    "stream": False,
                },
            )
            resp.raise_for_status()
            return resp.json()["message"]["content"]

    async def analyze_job(self, job_title: str, job_description: str, my_skills_profile: dict[str, Any]) -> dict[str, Any]:
        system = (
            "Score this job's relevance (0-100) to the given skills profile based on meaning, "
            'not just keywords. Respond ONLY with JSON: {"relevance_score": int, "reasoning": str, '
            '"matched_skills": [str]}.'
        )
        user = f"Skills: {my_skills_profile}\nTitle: {job_title}\nDescription: {job_description}"
        return extract_json(await self._complete(system, user))

    async def summarize_conversation(self, messages: list[dict[str, str]]) -> str:
        system = "Summarize this conversation in 2-4 plain sentences: project type, requirements, budget/timeline, sentiment."
        transcript = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        return await self._complete(system, transcript)

    async def calculate_lead_score(
        self,
        conversation_summary: str,
        extracted_requirements: dict[str, Any],
        message_history_tail: list[dict[str, str]],
    ) -> dict[str, Any]:
        system = (
            'Score client readiness 0-100. Respond ONLY with JSON: {"score": int, "signals": '
            '{"positive": [str], "negative": [str]}}.'
        )
        recent = "\n".join(f"{m['role']}: {m['content']}" for m in message_history_tail)
        user = f"Summary: {conversation_summary}\nRequirements: {extracted_requirements}\nRecent:\n{recent}"
        return extract_json(await self._complete(system, user))

    async def extract_requirements(self, conversation_text: str, existing_requirements: dict[str, Any]) -> dict[str, Any]:
        system = (
            "Merge new requirements from this conversation into the existing JSON. Never drop "
            "existing fields. Respond ONLY with the merged JSON object."
        )
        user = f"Existing: {existing_requirements}\nConversation:\n{conversation_text}"
        return extract_json(await self._complete(system, user))
