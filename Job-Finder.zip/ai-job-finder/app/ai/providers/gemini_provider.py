from __future__ import annotations

from typing import Any

import google.generativeai as genai

from app.ai.provider_interface import AIProvider
from app.ai.providers._json_utils import extract_json
from app.config import settings

_DEFAULT_MODEL = "gemini-1.5-flash"


class GeminiProvider(AIProvider):
    def __init__(self, model: str = _DEFAULT_MODEL) -> None:
        if not settings.GEMINI_API_KEY:
            raise RuntimeError("GEMINI_API_KEY is not set but AI_PROVIDER=gemini")
        genai.configure(api_key=settings.GEMINI_API_KEY)
        self._model_name = model

    def _model_client(self, system: str) -> genai.GenerativeModel:
        return genai.GenerativeModel(self._model_name, system_instruction=system)

    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: list[dict[str, str]],
        user_message: str,
    ) -> str:
        model = self._model_client(system_prompt)
        history = [
            {"role": "user" if m["role"] == "user" else "model", "parts": [m["content"]]}
            for m in conversation_history
        ]
        chat = model.start_chat(history=history)
        resp = await chat.send_message_async(user_message)
        return resp.text

    async def analyze_job(self, job_title: str, job_description: str, my_skills_profile: dict[str, Any]) -> dict[str, Any]:
        system = (
            "Score job relevance 0-100 by meaning, not keyword overlap. Respond ONLY with JSON: "
            '{"relevance_score": int, "reasoning": str, "matched_skills": [str]}.'
        )
        model = self._model_client(system)
        resp = await model.generate_content_async(
            f"Skills: {my_skills_profile}\nTitle: {job_title}\nDescription: {job_description}"
        )
        return extract_json(resp.text)

    async def summarize_conversation(self, messages: list[dict[str, str]]) -> str:
        system = "Summarize in 2-4 sentences: project type, requirements, budget/timeline, sentiment."
        model = self._model_client(system)
        transcript = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        resp = await model.generate_content_async(transcript)
        return resp.text

    async def calculate_lead_score(
        self,
        conversation_summary: str,
        extracted_requirements: dict[str, Any],
        message_history_tail: list[dict[str, str]],
    ) -> dict[str, Any]:
        system = 'Score readiness 0-100. Respond ONLY with JSON: {"score": int, "signals": {"positive": [str], "negative": [str]}}.'
        model = self._model_client(system)
        recent = "\n".join(f"{m['role']}: {m['content']}" for m in message_history_tail)
        resp = await model.generate_content_async(
            f"Summary: {conversation_summary}\nRequirements: {extracted_requirements}\nRecent:\n{recent}"
        )
        return extract_json(resp.text)

    async def extract_requirements(self, conversation_text: str, existing_requirements: dict[str, Any]) -> dict[str, Any]:
        system = "Merge new requirements into existing JSON, never dropping fields. Respond ONLY with merged JSON."
        model = self._model_client(system)
        resp = await model.generate_content_async(f"Existing: {existing_requirements}\nConversation:\n{conversation_text}")
        return extract_json(resp.text)
