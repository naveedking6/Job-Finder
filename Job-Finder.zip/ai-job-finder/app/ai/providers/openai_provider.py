from __future__ import annotations

from typing import Any

from openai import AsyncOpenAI

from app.ai.provider_interface import AIProvider
from app.ai.providers._json_utils import extract_json
from app.config import settings

_DEFAULT_MODEL = "gpt-4o-mini"


class OpenAIProvider(AIProvider):
    def __init__(self, model: str = _DEFAULT_MODEL) -> None:
        if not settings.OPENAI_API_KEY:
            raise RuntimeError("OPENAI_API_KEY is not set but AI_PROVIDER=openai")
        self._client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self._model = model

    async def _complete(self, system: str, user: str, json_mode: bool = False) -> str:
        kwargs: dict[str, Any] = {}
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        resp = await self._client.chat.completions.create(
            model=self._model,
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
            **kwargs,
        )
        return resp.choices[0].message.content or ""

    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: list[dict[str, str]],
        user_message: str,
    ) -> str:
        resp = await self._client.chat.completions.create(
            model=self._model,
            messages=[
                {"role": "system", "content": system_prompt},
                *conversation_history,
                {"role": "user", "content": user_message},
            ],
        )
        return resp.choices[0].message.content or ""

    async def analyze_job(self, job_title: str, job_description: str, my_skills_profile: dict[str, Any]) -> dict[str, Any]:
        system = (
            "Score job relevance 0-100 by meaning, not keyword overlap. Respond ONLY with JSON: "
            '{"relevance_score": int, "reasoning": str, "matched_skills": [str]}.'
        )
        user = f"Skills: {my_skills_profile}\nTitle: {job_title}\nDescription: {job_description}"
        return extract_json(await self._complete(system, user, json_mode=True))

    async def summarize_conversation(self, messages: list[dict[str, str]]) -> str:
        system = "Summarize in 2-4 sentences: project type, requirements, budget/timeline, sentiment."
        transcript = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        return await self._complete(system, transcript)

    async def calculate_lead_score(
        self,
        conversation_summary: str,
        extracted_requirements: dict[str, Any],
        message_history_tail: list[dict[str, str]],
    ) -> dict[str, Any]:
        system = 'Score readiness 0-100. Respond ONLY with JSON: {"score": int, "signals": {"positive": [str], "negative": [str]}}.'
        recent = "\n".join(f"{m['role']}: {m['content']}" for m in message_history_tail)
        user = f"Summary: {conversation_summary}\nRequirements: {extracted_requirements}\nRecent:\n{recent}"
        return extract_json(await self._complete(system, user, json_mode=True))

    async def extract_requirements(self, conversation_text: str, existing_requirements: dict[str, Any]) -> dict[str, Any]:
        system = "Merge new requirements into existing JSON, never dropping fields. Respond ONLY with merged JSON."
        user = f"Existing: {existing_requirements}\nConversation:\n{conversation_text}"
        return extract_json(await self._complete(system, user, json_mode=True))
