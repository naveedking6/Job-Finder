from __future__ import annotations

from typing import Any

from anthropic import AsyncAnthropic

from app.ai.provider_interface import AIProvider
from app.ai.providers._json_utils import extract_json
from app.config import settings

_DEFAULT_MODEL = "claude-sonnet-4-6"


class AnthropicProvider(AIProvider):
    def __init__(self, model: str = _DEFAULT_MODEL) -> None:
        if not settings.ANTHROPIC_API_KEY:
            raise RuntimeError("ANTHROPIC_API_KEY is not set but AI_PROVIDER=anthropic")
        self._client = AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
        self._model = model

    async def _complete(self, system: str, user: str, max_tokens: int = 1024) -> str:
        resp = await self._client.messages.create(
            model=self._model,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(block.text for block in resp.content if block.type == "text")

    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: list[dict[str, str]],
        user_message: str,
    ) -> str:
        resp = await self._client.messages.create(
            model=self._model,
            max_tokens=800,
            system=system_prompt,
            messages=[*conversation_history, {"role": "user", "content": user_message}],
        )
        return "".join(block.text for block in resp.content if block.type == "text")

    async def analyze_job(self, job_title: str, job_description: str, my_skills_profile: dict[str, Any]) -> dict[str, Any]:
        system = (
            "You score freelance job postings for relevance to a developer's skill profile. "
            "Understand meaning and intent, not just keyword overlap — e.g. 'online store for "
            "clothing brand' matches eCommerce/Shopify/WooCommerce skills even with no exact "
            "keyword match. Respond ONLY with a JSON object: "
            '{"relevance_score": <0-100 int>, "reasoning": "<1-2 sentences>", '
            '"matched_skills": ["skill1", "skill2"]}. No prose outside the JSON.'
        )
        user = f"Skills profile:\n{my_skills_profile}\n\nJob title: {job_title}\n\nJob description:\n{job_description}"
        raw = await self._complete(system, user)
        return extract_json(raw)

    async def summarize_conversation(self, messages: list[dict[str, str]]) -> str:
        system = (
            "Summarize this client conversation in 2-4 sentences a developer can read at a "
            "glance to instantly recall the context. Cover: project type, key requirements "
            "mentioned so far, budget/timeline if discussed, and current sentiment. Plain text only."
        )
        transcript = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        return await self._complete(system, transcript, max_tokens=300)

    async def calculate_lead_score(
        self,
        conversation_summary: str,
        extracted_requirements: dict[str, Any],
        message_history_tail: list[dict[str, str]],
    ) -> dict[str, Any]:
        system = (
            "Score how ready-to-buy this client is, 0-100, based on the signals below.\n"
            "Positive signals: detailed requirements, asks about price/timeline/portfolio, "
            "agrees to proceed, says 'I'm ready'/'let's start', shares contact info, wants to "
            "schedule a call.\n"
            "Negative signals: spam, unrealistic scope, unrelated work, evasiveness about "
            "requirements, suspicious/prohibited requests.\n"
            'Respond ONLY with JSON: {"score": <0-100 int>, "signals": '
            '{"positive": ["..."], "negative": ["..."]}}.'
        )
        recent = "\n".join(f"{m['role']}: {m['content']}" for m in message_history_tail)
        user = f"Summary so far: {conversation_summary}\n\nExtracted requirements: {extracted_requirements}\n\nRecent messages:\n{recent}"
        raw = await self._complete(system, user, max_tokens=400)
        return extract_json(raw)

    async def extract_requirements(self, conversation_text: str, existing_requirements: dict[str, Any]) -> dict[str, Any]:
        system = (
            "Extract/update structured project requirements from this conversation. Merge with "
            "the existing requirements given below — NEVER drop a field the client hasn't "
            "contradicted, only add or update. Fields of interest: project_type, platform_preference, "
            "product_count, has_existing_site, has_domain, budget, timeline, key_features, industry. "
            "Omit fields not yet mentioned. Respond ONLY with the merged JSON object."
        )
        user = f"Existing requirements: {existing_requirements}\n\nConversation:\n{conversation_text}"
        raw = await self._complete(system, user, max_tokens=500)
        return extract_json(raw)
