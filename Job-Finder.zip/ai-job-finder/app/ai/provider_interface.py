"""
Provider-agnostic AI interface (Phase 18).

Every AI provider (Anthropic, OpenAI, Gemini, Ollama) implements this same
interface. Nothing else in the codebase imports a provider SDK directly —
only app/ai/providers/*.py does. Swapping AI_PROVIDER in .env is the only
change needed to switch providers.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class AIProvider(ABC):
    """Every method returns plain Python types (str/dict/int) — never a raw SDK response."""

    @abstractmethod
    async def generate_response(
        self,
        system_prompt: str,
        conversation_history: list[dict[str, str]],
        user_message: str,
    ) -> str:
        """
        Generate the next reply in an ongoing conversation.

        conversation_history: list of {"role": "user"|"assistant", "content": str}
        Returns the assistant's reply as plain text.
        """
        ...

    @abstractmethod
    async def analyze_job(self, job_title: str, job_description: str, my_skills_profile: dict[str, Any]) -> dict[str, Any]:
        """
        Semantic relevance analysis (Phase 4) — NOT keyword matching.

        Returns: {"relevance_score": int 0-100, "reasoning": str, "matched_skills": list[str]}
        """
        ...

    @abstractmethod
    async def summarize_conversation(self, messages: list[dict[str, str]]) -> str:
        """Produce/update the running free-text summary stored in ConversationMemory."""
        ...

    @abstractmethod
    async def calculate_lead_score(
        self,
        conversation_summary: str,
        extracted_requirements: dict[str, Any],
        message_history_tail: list[dict[str, str]],
    ) -> dict[str, Any]:
        """
        Returns: {"score": int 0-100, "signals": {"positive": list[str], "negative": list[str]}}
        """
        ...

    @abstractmethod
    async def extract_requirements(self, conversation_text: str, existing_requirements: dict[str, Any]) -> dict[str, Any]:
        """
        Merge newly-mentioned requirements into the existing structured dict.
        Never drops previously captured fields the client hasn't contradicted.
        """
        ...
