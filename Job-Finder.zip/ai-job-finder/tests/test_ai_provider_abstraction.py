import pytest

from app.ai.provider_interface import AIProvider


class FakeProvider(AIProvider):
    """Minimal concrete implementation used to prove the ABC contract is satisfiable and callable."""

    async def generate_response(self, system_prompt, conversation_history, user_message):
        return f"echo: {user_message}"

    async def analyze_job(self, job_title, job_description, my_skills_profile):
        return {"relevance_score": 90, "reasoning": "test", "matched_skills": ["wordpress"]}

    async def summarize_conversation(self, messages):
        return "summary"

    async def calculate_lead_score(self, conversation_summary, extracted_requirements, message_history_tail):
        return {"score": 75, "signals": {"positive": ["asked for price"], "negative": []}}

    async def extract_requirements(self, conversation_text, existing_requirements):
        return {**existing_requirements, "project_type": "ecommerce"}


def test_ai_provider_is_abstract():
    """Cannot instantiate AIProvider directly — every provider must implement all 5 methods."""
    with pytest.raises(TypeError):
        AIProvider()  # type: ignore[abstract]


@pytest.mark.asyncio
async def test_fake_provider_satisfies_interface():
    provider: AIProvider = FakeProvider()

    reply = await provider.generate_response("system", [], "hello")
    assert reply == "echo: hello"

    analysis = await provider.analyze_job("title", "desc", {"skills": ["wordpress"]})
    assert analysis["relevance_score"] == 90

    summary = await provider.summarize_conversation([{"role": "user", "content": "hi"}])
    assert summary == "summary"

    score = await provider.calculate_lead_score("summary", {}, [])
    assert score["score"] == 75
    assert "asked for price" in score["signals"]["positive"]

    reqs = await provider.extract_requirements("text", {"budget": 1000})
    assert reqs["budget"] == 1000  # existing field preserved
    assert reqs["project_type"] == "ecommerce"  # new field added


def test_factory_rejects_unknown_provider(monkeypatch):
    from app.ai.factory import get_ai_provider

    get_ai_provider.cache_clear()
    monkeypatch.setattr("app.config.settings.AI_PROVIDER", "not_a_real_provider")
    with pytest.raises(ValueError, match="Unknown AI_PROVIDER"):
        get_ai_provider()
    get_ai_provider.cache_clear()


def test_factory_dispatches_to_ollama_without_api_key(monkeypatch):
    """Ollama needs no API key (it's the free/local option) — should construct cleanly."""
    from app.ai.factory import get_ai_provider
    from app.ai.providers.ollama_provider import OllamaProvider

    get_ai_provider.cache_clear()
    monkeypatch.setattr("app.config.settings.AI_PROVIDER", "ollama")
    provider = get_ai_provider()
    assert isinstance(provider, OllamaProvider)
    get_ai_provider.cache_clear()
