from app.models.enums import LeadStage, OpportunityStatus, PlatformCapability
from app.models.lead import Client, Lead
from app.models.opportunity import Opportunity
from app.models.platform import Platform


def _seed_lead(db_session):
    platform = Platform(name="own_site", capability=PlatformCapability.DISCOVER_RESPOND.value, enabled=True)
    db_session.add(platform)
    db_session.commit()

    opp = Opportunity(
        platform_id=platform.id,
        external_ref="ref-1",
        title="Need a WordPress developer",
        description="Small business site redesign",
        status=OpportunityStatus.SCORED.value,
        relevance_score=75,
    )
    db_session.add(opp)
    db_session.commit()

    c = Client(name="Test Client")
    db_session.add(c)
    db_session.commit()

    lead = Lead(opportunity_id=opp.id, client_id=c.id, stage=LeadStage.OPPORTUNITY_ANALYZED.value, lead_score=30)
    db_session.add(lead)
    db_session.commit()
    return opp, lead


def test_health_is_public(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_leads_requires_auth(client):
    resp = client.get("/leads")
    assert resp.status_code == 401


def test_list_opportunities(client, db_session, auth_headers):
    _seed_lead(db_session)
    resp = client.get("/opportunities", headers=auth_headers)
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 1
    assert body[0]["title"] == "Need a WordPress developer"


def test_list_leads_and_update_stage(client, db_session, auth_headers):
    _opp, lead = _seed_lead(db_session)

    resp = client.get("/leads", headers=auth_headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 1

    resp = client.patch(
        f"/leads/{lead.id}/stage",
        headers=auth_headers,
        json={"stage": "budget_discussion"},
    )
    assert resp.status_code == 200
    assert resp.json()["stage"] == "budget_discussion"


def test_update_lead_invalid_stage_rejected(client, db_session, auth_headers):
    _opp, lead = _seed_lead(db_session)
    resp = client.patch(
        f"/leads/{lead.id}/stage",
        headers=auth_headers,
        json={"stage": "not_a_real_stage"},
    )
    assert resp.status_code == 400


def test_automation_stop_and_status(client, auth_headers):
    resp = client.post("/automation/stop", headers=auth_headers)
    assert resp.status_code == 200
    assert resp.json()["automation_enabled"] is False

    resp = client.get("/automation/status", headers=auth_headers)
    assert resp.json()["automation_enabled"] is False

    resp = client.post("/automation/start", headers=auth_headers)
    assert resp.json()["automation_enabled"] is True
