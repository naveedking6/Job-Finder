import os

os.environ.setdefault("SECRET_KEY", "test_secret")
os.environ.setdefault("WHATSAPP_NUMBER", "923001234567")
os.environ.setdefault("ADMIN_EMAIL", "test@example.com")
# bcrypt hash of "testpass123", pre-generated so tests don't need bcrypt at collection time
os.environ.setdefault(
    "ADMIN_PASSWORD_HASH",
    "$2b$12$na1iGD1VCueyIwq8OdIzSuCKhG62xiUH6aIZ9n6GJDbmzb7FGhni6",  # noqa: E501
)
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.api.deps import get_db
from app.db.session import Base
from app.main import app

TEST_ENGINE = create_engine(
    "sqlite:///:memory:",
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestSessionLocal = sessionmaker(bind=TEST_ENGINE, autoflush=False, autocommit=False)


@pytest.fixture()
def db_session():
    import app.models  # noqa: F401 registers tables

    Base.metadata.create_all(TEST_ENGINE)
    session = TestSessionLocal()
    try:
        yield session
    finally:
        session.close()
        Base.metadata.drop_all(TEST_ENGINE)


@pytest.fixture()
def client(db_session):
    def _override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = _override_get_db
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture()
def auth_headers():
    import base64

    token = base64.b64encode(b"test@example.com:testpass123").decode()
    return {"Authorization": f"Basic {token}"}
