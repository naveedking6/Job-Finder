"""Usage: python3 scripts/hash_password.py
Prompts for a password, prints the bcrypt hash to put in .env as ADMIN_PASSWORD_HASH.
"""
import getpass

import bcrypt

if __name__ == "__main__":
    pw = getpass.getpass("Admin password: ")
    confirm = getpass.getpass("Confirm: ")
    if pw != confirm:
        raise SystemExit("Passwords did not match.")
    hashed = bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
    print("\nAdd this to your .env file:\n")
    print(f"ADMIN_PASSWORD_HASH={hashed}")
